<template>
  <ListaPubs mensagem="Teste" get='pubs' idGet=""/>
</template>

<script>
import ListaPubs from "@/components/ListaPubs.vue";

export default {
  components: {
    ListaPubs
  },

};
</script>
