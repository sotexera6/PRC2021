<template>
  <VerPub mensagem="Teste" :idP='this.$router.params.id'/>
</template>

<script>
import VerPub from "@/components/VerPub.vue";

export default {
  components: {
    VerPub
  },

};
</script>
