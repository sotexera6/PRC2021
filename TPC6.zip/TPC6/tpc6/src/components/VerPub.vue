<template>
  <div class="w3-container">
    <h3 class="w3-header w3-blue">Publicação</h3>
    <table class="w3-table-all">
        <tr>
            <th>ID</th><th>Tipo{{$res}}</th><th>Ano</th><th>Título{{dados}}</th>
        </tr>
        <tr v-for="(d, i) in dados" :key="i">
            <td>{{d}}</td><td>{{d.type}}</td><td>{{d.year}}</td><td>{{d.title}}</td>
        </tr>
    </table>
  </div> 
</template>
<script>
import axios from 'axios';

  export default {
    name: 'Pub',

    props: ["mensagem", "idP"],

    data() {
      return {
            dados: null
        };
    },

    created: function() {
      axios
        .get('http://localhost:8080/site/pubs/cisti2017/')
        .then(res => {
          this.dados = res.data
          this.res = $route.params.id
        })
        .catch(e => this.error = 'error' + e)
    },

    methods: {
        goPub: function(id){
            this.$router.push('/pubs/' + id);
        }
    }
  }
</script>
<style>
  h3 {
    margin-bottom: 5%;
  }
</style>